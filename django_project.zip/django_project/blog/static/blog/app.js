// $(function(){
//   $('#myModal').modal('show');
//   return false;
// });

function showDiv(x)
{
  $('#'+x).modal('show');
}

//
// $(function(){
//
// $('#trigger').click(function(){
//   $('#myModal').modal('show');
//   return false;
// })
//
// });

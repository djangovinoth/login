from django.apps import AppConfig


class HrpanelConfig(AppConfig):
    name = 'hrpanel'
